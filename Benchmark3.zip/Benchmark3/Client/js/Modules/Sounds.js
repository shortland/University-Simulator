export class Sounds {
  constructor() {
    this.test = "a";
  }

  // playMusic() {
  //   return this.music.play();
  // }
}